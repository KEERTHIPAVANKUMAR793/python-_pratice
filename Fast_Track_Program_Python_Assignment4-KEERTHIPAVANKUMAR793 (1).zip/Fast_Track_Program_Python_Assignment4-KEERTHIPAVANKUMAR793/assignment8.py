n=int(input("Enter the value"))
if n%2==0:
    print(n,"is even number")
else:
    print(n,"is odd number")
        
        