for i in range(5):
    for j in range(i+1):
        print("a",end="")
    print()
    
for i in range(5):
    for j in range(5-i):
        print("d",end="")
    print() 