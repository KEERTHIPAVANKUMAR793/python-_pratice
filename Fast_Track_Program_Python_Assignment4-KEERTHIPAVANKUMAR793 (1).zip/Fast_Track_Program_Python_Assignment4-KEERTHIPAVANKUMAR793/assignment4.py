for i in range(5):
    for j in range(5):
        print("*",end="")
    print()