n=int(input("number of rows:"))
for i in range():
    for j in range(n-i):
        print(j+1,end="")
        print()