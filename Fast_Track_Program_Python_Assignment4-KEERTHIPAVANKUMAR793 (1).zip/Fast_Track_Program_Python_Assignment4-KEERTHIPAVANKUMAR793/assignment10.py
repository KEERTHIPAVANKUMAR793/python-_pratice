n=int(input("enter the  value"))
if n%2==0:
    print(n,"is even number")
else:
    print(n,"is odd number")
n=int(input("enter the  value"))
if n%5==0:
    print(n,"is prime number")
else:
    print(n,"is even number")